#include "agent_rules.h"
#include <rules.h>

#include <ostream>
#include <print>

namespace nano_edr {

const char* SeverityName(Severity severity){
    switch (severity){
        case Severity::kLow:
            return "low";
        case Severity::kMedium:
            return "medium";
        case Severity::kHigh:
            return "high";
        case Severity::kCritical:
            return "critical";
    }
    return "?";
}

size_t CheckRules(const Event& event, const Rule* rules, size_t rule_count){
    size_t detected = 0;
    for (size_t i = 0; i < rule_count; i++){
        const Rule& rule = rules[i];
        if (rule.check(event)){
            detected++;
            std::print("[DETECT] {}  {}  ts={} pid={}\n", SeverityName(rule.severity), rule.id, event.raw_ts(), event.pid());
        }
    }
    return detected;
}

}  
